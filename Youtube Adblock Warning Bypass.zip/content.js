// content.js

// Remove specified HTML elements
function removeElements() {
  const backdropElement = document.querySelector('tp-yt-iron-overlay-backdrop.opened');
  const dialogElement = document.querySelector('tp-yt-paper-dialog');
  
  if (backdropElement) {
    backdropElement.remove();
  }
  
  if (dialogElement) {
    dialogElement.remove();
  }
}

// Execute the removal function when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', removeElements);
